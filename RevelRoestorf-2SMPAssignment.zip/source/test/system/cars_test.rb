require "application_system_test_case"

class CarsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit cars_url
  #
  #   assert_selector "h1", text: "Car"
  # end
end
