require 'test_helper'

class BookingConfirmationMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
