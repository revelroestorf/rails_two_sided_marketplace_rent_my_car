# Preview all emails at http://localhost:3000/rails/mailers/owner_booking_notifier_mailer
class OwnerBookingNotifierMailerPreview < ActionMailer::Preview

end
