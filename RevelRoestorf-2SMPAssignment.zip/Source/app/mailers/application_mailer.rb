class ApplicationMailer < ActionMailer::Base
  default :from => 'noreply@rentmycar.com'
  layout 'mailer'
end
