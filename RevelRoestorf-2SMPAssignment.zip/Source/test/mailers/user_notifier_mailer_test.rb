require 'test_helper'

class UserNotifierMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
