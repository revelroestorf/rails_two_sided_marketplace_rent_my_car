# Preview all emails at http://localhost:3000/rails/mailers/booking_confirmation_mailer
class BookingConfirmationMailerPreview < ActionMailer::Preview

end
