require 'test_helper'

class OwnerBookingNotifierMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
